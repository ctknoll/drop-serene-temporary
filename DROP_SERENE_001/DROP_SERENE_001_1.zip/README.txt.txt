Controls:
	WASD to move
	LMB to toggle flashlight
	ESC to quit
	P to toggle pause
	R to restart
	L to togge lighting for development purposes

Contact with monster will reset the scene